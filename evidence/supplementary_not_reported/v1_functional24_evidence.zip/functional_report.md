# Functional development test results

Completed: 24/24. Not an independent or final evaluation.

This deliberately simple suite contains 16 routine cases, 4 emergency-rule cases and 4 review-policy cases. Do not compare its aggregate accuracy or review rate directly with the 150-case evaluation. Four intended reviews already imply a 16.7% review rate for a perfect policy match, so this suite cannot establish the 12% target.

| Metric | Baseline | RAG |
|---|---:|---:|
| dangerous_misses | 0 | 0 |
| department_accuracy | 0.5625 | 0.9375 |
| routine_review_rate | 0.4375 | 0.0625 |
| human_review_rate | 0.4166666666666667 | 0.16666666666666666 |
| api_attempts | 0 | 16 |
| validated_llm_outputs | 0 | 16 |
| integration_error_count | 0 | 0 |
| known_provider_reported_cost | None | 0.0056568 |